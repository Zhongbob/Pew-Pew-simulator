const button = document.getElementById('showBtn');
const message = document.getElementById('message');

button.addEventListener('click', () => {
  message.textContent = "✔️ Always remember to follow the rules strictly!";
});