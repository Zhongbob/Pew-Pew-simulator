# Page2

A Pen created on CodePen.

Original URL: [https://codepen.io/George-Kuruvi/pen/azvpMGL](https://codepen.io/George-Kuruvi/pen/azvpMGL).

